const express = require("express");
const axios = require("axios");
const path = require("path");
const cors = require("cors");
const http = require('http');
const { WebSocketServer } = require('ws');
const app = express();
require("dotenv").config();

// Set default JWT_SECRET if not provided
process.env.JWT_SECRET = process.env.JWT_SECRET || 'defaultjwtsecretfordemo';

// Global default AI provider (can be overridden by env or per-request)
const DEFAULT_AI_PROVIDER = (process.env.DEFAULT_AI_PROVIDER || 'gpt5mini').toLowerCase();

// Enable CORS for deployment (adjust origin as needed)
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());

// Auth endpoints and middleware
const { router: authRouter, authenticateJWT } = require("./api/auth");
app.use("/api", authRouter);

// Mount Agora integration API (real integration)
app.use("/api", require("./api/agora"));

// Mount multi-platform streaming API
app.use("/api", require("./api/stream"));

// Mount AI/ML API (Azure OpenAI and Vertex AI) - protected
app.use("/api", authenticateJWT, require("./api/ai"));

// Mount behavioral analysis API - protected
app.use("/api", authenticateJWT, require("./api/behavioral"));

// Mount batch sentiment analysis API - protected
app.use("/api", require("./api/sentiment-batch"));


// Mount external live interaction API
// Lazily require modules to avoid startup-time crashes when a dependency
// uses newer JS syntax that the platform may not support during initial
// module loading. The lazy loader will require the module on first
// request and cache the router.
function lazyRequire(modulePath) {
  let cached = null;
  return function(req, res, next) {
    if (!cached) {
      try {
        const mod = require(modulePath);
        cached = (mod && mod.router) ? mod.router : mod;
      } catch (err) {
        console.error(`Lazy require failed for ${modulePath}:`, err && err.stack || err);
        return next(err);
      }
    }
    return cached(req, res, next);
  };
}

app.use("/api", lazyRequire("./api/live"));

// Mount admin API (admin-only health/status)
app.use("/api", authenticateJWT, require("./api/admin"));

// Mount user APIs
app.use("/api", lazyRequire("./api/campaigns"));
app.use("/api", lazyRequire("./api/forum"));
app.use("/api", lazyRequire("./api/talent"));
app.use("/api", lazyRequire("./api/feedback"));
app.use("/api", lazyRequire("./api/metrics"));
app.use("/api", lazyRequire("./api/profile"));
app.use("/api", lazyRequire("./api/engagement"));

// Serve static frontend (for deployment, serve root and frontend)
app.use(express.static(path.join(__dirname, "frontend")));
app.use(express.static(__dirname));


const PORT = process.env.PORT || 3000;

// Create HTTP server and attach WebSocket server for real-time features
const server = http.createServer(app);

// In-memory state for live features (demo only)
const qaQueue = []; // { id, text, user, ts }
const reactionCounts = {}; // emoji => count

const wss = new WebSocketServer({ server, path: '/live-socket' });

function broadcast(event) {
  const msg = JSON.stringify(event);
  wss.clients.forEach(client => {
    if (client.readyState === client.OPEN) client.send(msg);
  });
}

wss.on('connection', (socket, req) => {
  console.log('WS client connected');
  // Send initial state
  try { socket.send(JSON.stringify({ type: 'init', payload: { qaQueue, reactionCounts } })); } catch (e) {}
  socket.on('message', (raw) => {
    let msg = null;
    try { msg = JSON.parse(raw.toString()); } catch (err) { return; }
    if (!msg || !msg.type) return;
    // Handle inbound events from clients and broadcast to others
    if (msg.type === 'reaction') {
      const emoji = msg.payload && msg.payload.emoji;
      reactionCounts[emoji] = (reactionCounts[emoji] || 0) + 1;
      broadcast({ type: 'reaction', payload: { emoji, count: reactionCounts[emoji] } });
    } else if (msg.type === 'question') {
      const q = Object.assign({ id: Date.now().toString(36) }, msg.payload || {});
      qaQueue.push(q);
      broadcast({ type: 'question', payload: q });
    } else if (msg.type === 'moderation') {
      const { action, qid } = msg.payload || {};
      if (action === 'approve' || action === 'dismiss') {
        // remove from queue
        const idx = qaQueue.findIndex(x => (x.id == qid || x.ts == qid));
        if (idx !== -1) qaQueue.splice(idx,1);
        broadcast({ type: 'moderation', payload: { action, qid, text: msg.payload && msg.payload.text } });
      }
    }
  });
  socket.on('close', () => console.log('WS client disconnected'));
});


// REST fallback endpoints for clients that cannot use WebSocket
app.post('/api/live/event', (req, res) => {
  const { type, payload } = req.body || {};
  if (!type) return res.status(400).json({ error: 'Missing event type' });
  // Optionally process server-side
  if (type === 'reaction' && payload && payload.emoji) {
    reactionCounts[payload.emoji] = (reactionCounts[payload.emoji] || 0) + 1;
    broadcast({ type: 'reaction', payload: { emoji: payload.emoji, count: reactionCounts[payload.emoji] } });
  }
  if (type === 'question' && payload && payload.text) {
    const q = Object.assign({ id: Date.now().toString(36) }, payload);
    qaQueue.push(q);
    broadcast({ type: 'question', payload: q });
  }
  res.json({ status: 'ok' });
});

app.post('/api/live/question', (req, res) => {
  const { text, user } = req.body || {};
  if (!text) return res.status(400).json({ error: 'Missing text' });
  const q = { id: Date.now().toString(36), text, user: user || 'guest', ts: Date.now() };
  qaQueue.push(q);
  broadcast({ type: 'question', payload: q });
  res.json({ status: 'queued', question: q });
});

app.get('/api/live/queue', (req, res) => {
  res.json(qaQueue);
});

// Fallback to index.html for SPA (must be after API routes)
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// Start the HTTP server after all routes are registered
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log("Agora live integration is ready for deployment.");

  // Startup environment checks for AI provider keys
  const missingKeys = [];
  if (!process.env.VERTEX_AI_KEY) missingKeys.push('VERTEX_AI_KEY');
  if (!process.env.AZURE_OPENAI_KEY) missingKeys.push('AZURE_OPENAI_KEY');
  if (!process.env.GPT5_MINI_KEY) missingKeys.push('GPT5_MINI_KEY');

  // Check for critically missing keys: JWT_SECRET and the default provider key
  const criticalMissing = [];
  if (!process.env.JWT_SECRET) criticalMissing.push('JWT_SECRET');
  if (DEFAULT_AI_PROVIDER === 'gpt5mini' && !process.env.GPT5_MINI_KEY) criticalMissing.push('GPT5_MINI_KEY');
  if (DEFAULT_AI_PROVIDER === 'azure' && !process.env.AZURE_OPENAI_KEY) criticalMissing.push('AZURE_OPENAI_KEY');
  if (DEFAULT_AI_PROVIDER === 'vertex' && !process.env.VERTEX_AI_KEY) criticalMissing.push('VERTEX_AI_KEY');

  if (missingKeys.length > 0) {
    console.warn('\n[WARNING] Missing environment variables for AI providers:');
    missingKeys.forEach(k => console.warn(` - ${k}`));
    console.warn('\nAdd them to your local .env (copy .env.example) or set them in your deployment/CI secrets.');
  } else {
    console.log('All AI provider keys present.');
  }

  if (criticalMissing.length > 0) {
    console.warn('\n[CRITICAL] Missing required runtime secrets:');
    criticalMissing.forEach(k => console.warn(` - ${k}`));
    if (process.env.NODE_ENV === 'production') {
      console.error('\nMissing critical secrets in production - exiting to avoid running without required secrets.');
      process.exit(1);
    } else {
      console.warn('\nRunning in non-production mode; set these secrets before deploying to production.');
    }
  }
});
