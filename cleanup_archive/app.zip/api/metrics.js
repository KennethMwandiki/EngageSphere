const express = require('express');
const router = express.Router();

// GET /api/metrics - Dashboard metrics
router.get('/metrics', (req, res) => {
  // Simulate metrics
  res.json({
    campaigns: 5, // Hardcoded for demo
    users: 100
  });
});

module.exports = router;