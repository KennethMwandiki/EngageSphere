const express = require('express');
const router = express.Router();

// In-memory storage (per user, but simplified)
let profiles = {};

// POST /api/profile - Update profile
router.post('/profile', (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Name and email required' });
  profiles[email] = { name, email };
  res.json({ message: 'Profile updated' });
});

module.exports = router;