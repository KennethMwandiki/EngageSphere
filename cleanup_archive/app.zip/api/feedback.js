const express = require('express');
const router = express.Router();

// In-memory storage
let feedbackList = [];

// GET /api/feedback - List feedback
router.get('/feedback', (req, res) => {
  res.json(feedbackList);
});

// POST /api/feedback - Submit feedback
router.post('/feedback', (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'Text required' });
  const feedback = { id: Date.now(), text };
  feedbackList.push(feedback);
  res.json(feedback);
});

module.exports = router;