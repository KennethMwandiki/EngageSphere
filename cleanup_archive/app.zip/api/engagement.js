const express = require('express');
const router = express.Router();

// In-memory storage
let engagements = [];

// POST /api/engagement - Log interaction
router.post('/engagement', (req, res) => {
  const { action } = req.body;
  const log = { id: Date.now(), action: action || 'interaction' };
  engagements.push(log);
  res.json({ message: 'Engagement logged' });
});

module.exports = router;