const express = require('express');
const router = express.Router();

// In-memory storage
let talentApplications = [];

// GET /api/talent - List applications
router.get('/talent', (req, res) => {
  res.json(talentApplications);
});

// POST /api/talent - Apply
router.post('/talent', (req, res) => {
  const { name, skills } = req.body;
  if (!name || !skills) return res.status(400).json({ error: 'Name and skills required' });
  const application = { id: Date.now(), name, skills };
  talentApplications.push(application);
  res.json(application);
});

module.exports = router;