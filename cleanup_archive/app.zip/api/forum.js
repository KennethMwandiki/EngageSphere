const express = require('express');
const router = express.Router();

// In-memory storage
let forumPosts = [];

// GET /api/forum - List posts
router.get('/forum', (req, res) => {
  res.json(forumPosts);
});

// POST /api/forum - Add post
router.post('/forum', (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'Text required' });
  const post = { id: Date.now(), text };
  forumPosts.push(post);
  res.json(post);
});

module.exports = router;