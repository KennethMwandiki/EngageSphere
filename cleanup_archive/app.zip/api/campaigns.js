const express = require('express');
const router = express.Router();

// In-memory storage (replace with DB in production)
let campaigns = [];

// GET /api/campaigns - List campaigns
router.get('/campaigns', (req, res) => {
  res.json(campaigns);
});

// POST /api/campaigns - Create campaign
router.post('/campaigns', (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'Name required' });
  const campaign = { id: Date.now(), name };
  campaigns.push(campaign);
  res.json(campaign);
});

module.exports = router;