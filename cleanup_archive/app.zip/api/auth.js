// Simple JWT authentication backend (Node.js/Express)
const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET;

// Development-only users (do not use in production). Remove before publishing production systems.
const USERS = [
  { username: 'admin', password: 'adminpass', role: 'admin' },
  { username: 'user', password: 'userpass', role: 'user' }
];

if (!JWT_SECRET) {
  console.warn('WARNING: JWT_SECRET is not set. For local development, set JWT_SECRET in your environment. Do NOT use default secrets in production.');
}

// POST /api/auth/signup
router.post('/auth/signup', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'All fields required' });
  const existing = USERS.find(u => u.username === email);
  if (existing) return res.status(409).json({ error: 'User already exists' });
  const newUser = { username: email, password, role: 'user' }; // Default role: user
  USERS.push(newUser);
  res.json({ message: 'User registered successfully' });
});

// Middleware to protect routes
function authenticateJWT(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return res.status(401).json({ error: 'No token provided' });
  const token = authHeader.split(' ')[1];
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid token' });
    req.user = user;
    next();
  });
}

module.exports = { router, authenticateJWT };
